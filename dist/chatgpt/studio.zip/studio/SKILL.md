---

name: studio-chatgpt-studio-delivery
description: Studio v2.0.0: skills-first ChatGPT workflow for bounded software delivery.
---
# Studio

This archive contains portable Skills only. It does not declare an MCP server, require localhost, a tunnel, an API key, or a connected app.

Route to the smallest relevant skill, read the current project state, keep writes confirmation-gated, and report evidence honestly.
