---

name: studio-chatgpt-interface-studio
description: Use the Studio Design Studio workflow as a skills-first ChatGPT package.
---
# Studio Design

This archive contains portable Skills only. It does not declare an MCP server, require localhost, a tunnel, an API key, or a connected app.

Route to the smallest relevant skill, read the current project state, keep writes confirmation-gated, and report evidence honestly.
