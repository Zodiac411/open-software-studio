---

name: studio-chatgpt-research-engineer
description: Use the Studio Research Studio workflow as a skills-first ChatGPT package.
---
# Studio Research

This archive contains portable Skills only. It does not declare an MCP server, require localhost, a tunnel, an API key, or a connected app.

Route to the smallest relevant skill, read the current project state, keep writes confirmation-gated, and report evidence honestly.
